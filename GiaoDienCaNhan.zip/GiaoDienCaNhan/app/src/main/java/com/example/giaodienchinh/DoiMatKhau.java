package com.example.giaodienchinh;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DoiMatKhau extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doi_mat_khau);
    }
}